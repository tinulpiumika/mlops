#import only the necessary libraries

import glob 
import pyarrow.parquet as pq
import pickle
import datetime
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)
import argparse
import os
import boto3
import json

print("import your necessary libraries in here") 
import pandas as pd 
import numpy as np


print('successflly import the libaries')

print("enter your project name and enviornment here")
project_name = "aws_workshop"
user_name='mlops'
env = 'dev'

print("loading the stage config data from s3")

def getJsonData(bucket_name,key_name):
    print("[LOG]", bucket_name,'---------')
    print("[LOG]", key_name,'--------------')
      
    s3_client = boto3.client('s3')
    csv_obj = s3_client.get_object(Bucket=bucket_name, Key=key_name)
    
    body = csv_obj['Body']
    
    json_string = body.read().decode('utf-8')
    json_content = json.loads(json_string)
    
    return json_content

print("setting the parameters for getJsonData function")
config_bucket = f"dlk-cloud-tier-8-code-ml-{env}"
config_s3_prefix_stage = f'config_files/stage_config/{project_name}/{user_name}/stage_config.json'

print("calling the getJsonData function")
config = getJsonData(config_bucket,config_s3_prefix_stage)

print("json script loaded successfully")




if __name__ == "__main__":
    
    input_data_path = os.path.join("/opt/ml/processing/input", config["postpreprocessing"]["local_paths"]["input1"])
    
    input_data_path1 = os.path.join("/opt/ml/processing/input1", config["postpreprocessing"]["local_paths"]["input2"])

    print("reading input data from {}".format(input_data_path))
    
    df1 = pd.read_csv(input_data_path,header=None)
    
    print('loading the preprocess dataset')
    df= pd.read_csv(input_data_path1,header=None)
    
    ################### Enter your own script in here #######################
      

    print('renaming the prediction output dataset')      
    df1.rename(columns={0:'churn_prop'}, inplace=True)
    
    print('columns selecting')
    columns = config["postpreprocessing"]["columns"]["selected_columns"]
    print('renaming the colums')
    df.columns = columns
    
    print('add churn probabilty variable to preprocess dataset')
    df['Churn_probability']=df1['churn_prop']

    data_cmp_df = df[['customerID','Churn_probability']]
    
    print('sorting the first five hundred customers')
    data_cmp_df=data_cmp_df.sort_values("Churn_probability", ascending=False).head(500)
          
    #################### End of the code ##############################   
    print("saving the dataframe")

    # Saving outputs.(must be header = False)
    inf_features_output_path = os.path.join("/opt/ml/processing/post_output1", config["postpreprocessing"]["local_paths"]["output1"])
    
    
    print("saving training features to {}".format(inf_features_output_path))
    pd.DataFrame(data_cmp_df).to_csv(inf_features_output_path, compression='gzip',index=False)

    print("successfully completed the post-processing job")
