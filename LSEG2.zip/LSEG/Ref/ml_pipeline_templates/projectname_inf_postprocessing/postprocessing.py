import boto3
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)
import argparse
import os
warnings.simplefilter(action='ignore')
import json
import pytz
from datetime import datetime

print("import your necessary libraries in here")
import numpy as np
import pandas as pd
from sklearn import preprocessing
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split






print("enter your project name with BU Name here.") #please follow the taxonomy file
project_name = "BUName_projectname" 
env = 'dev

###################################### configuration file management ###############################


print("setup the date folder to do the data versioning")
srilanka_tz = pytz.timezone('Asia/Colombo')
s3 = boto3.client('s3')
date_folder = datetime.now(srilanka_tz).strftime("%Y-%m-%d")


print("setting up the stage configuration file into this file")

print("pick the latest trained config file")
def latest_config(config_type):
    '''
    this will pick the latest trained config file
    '''

    s3_path = f"s3://dlk-cloud-tier-8-code-ml-{env}/"
    config_bucket = f"dlk-cloud-tier-8-code-ml-{env}"
    s3 = boto3.client('s3')
    all_objects = s3.list_objects(Bucket = f"dlk-cloud-tier-8-code-ml-{env}", Prefix=f"config_files/{config_type}/{project_name}/")
    model_folder=all_objects['Contents'][-1]['Key']
    #model_path=s3_path+model_folder
    
    return config_bucket, model_folder

print("calling the latest stage config file")
config_type = "stage_config"
config_bucket = latest_config(config_type)[0]
model_path = latest_config(config_type)[1]

print("loading the stage config data from s3")

print("import the getJsonData function")
def getJsonData(bucket_name,key_name):
    '''
    this will pick the json config file from s3 bucket
    '''
    
    print("[LOG]", bucket_name,'---------')
    print("[LOG]", key_name,'--------------')
      
    s3_client = boto3.client('s3')
    csv_obj = s3_client.get_object(Bucket=bucket_name, Key=key_name)
    
    body = csv_obj['Body']
    
    json_string = body.read().decode('utf-8')
    json_content = json.loads(json_string)
    
    return json_content


config = getJsonData(config_bucket, model_path)



print("json script loaded successfully")
#########################################################################################

 
if __name__ == "__main__":

    input_data_path = os.path.join("/opt/ml/processing/post-input1", config['postpreprocessing']["local_paths"]['input1'])
    #input_data_path2 = os.path.join("/opt/ml/processing/post-input2", config["postpreprocessing"]["local_paths"]["input2"])
    #input_data_path3 = os.path.join("/opt/ml/processing/post-input3", config["postpreprocessing"]["local_paths"]["input3"])
    #input_data_path4 = os.path.join("/opt/ml/processing/post-input4", config["postpreprocessing"]["local_paths"]["input4"])

    print("Reading input data")
    df = pd.read_csv(input_data_path)
    #df2 = pd.read_csv(input_data_path2)
    #df3 = pd.read_csv(input_data_path3)
    #df4 = pd.read_csv(input_data_path4)
    
    
    
    print("renaming the columns")
    
    column_names = config["postpreprocessing"]["columns"]["input1-selected_columns"]
    df.columns = column_names
    
    #column_names2 = config["postpreprocessing"]["columns"]["input2-selected_columns"]
    #df2.columns = column_names
    
    ############################################### Enter your own script here ##################################
    
    
    
    
    ######################################### End of the code ####################################################
    
 
    # ------------------please change the below final datafrane namee according to above script - onetime work - line 124
    print("saving the final dataframe")
    final_base_path = os.path.join("/opt/ml/processing/post-output1", config['postpreprocessing']["local_paths"]['output1'])
    print("saving output to {}".format(final_base_path))
    pd.DataFrame(final_base).to_csv(final_base_path, header=False, index=False)
    
    # ------------------if you have more than two dataframes to save please uncomment the below lines
    #final_base_path2 = os.path.join("/opt/ml/processing/post-output2", config['postpreprocessing']["local_paths"]['output2'])
    #print("saving output to {}".format(final_base_path2))
    #pd.DataFrame(final_base2).to_csv(final_base_path2, header=False, index=False)
    
    print("successfully completed the postprocessing")
