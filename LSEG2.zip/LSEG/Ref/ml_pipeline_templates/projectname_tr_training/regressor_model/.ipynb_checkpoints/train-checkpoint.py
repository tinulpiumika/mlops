import os
import argparse
import pickle
import boto3
from datetime import datetime
import pytz
import io
from io import StringIO
import tempfile
import joblib
import json

print("import your necessary libraries here")
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import classification_report
from sklearn.model_selection import GridSearchCV
from sklearn.utils import class_weight
from sklearn.metrics import accuracy_score, precision_score, recall_score,f1_score,confusion_matrix,roc_auc_score
from xgboost import XGBClassifier
import numpy as np

print("enter your project name with BU Name here.") #please follow the taxonomy file
project_name = "mobile_prepaidchurn"
env = 'dev'

###################################### configuration file management ###############################


print("setup the date folder to do the data versioning")
srilanka_tz = pytz.timezone('Asia/Colombo')
s3 = boto3.client('s3')
date_folder = datetime.now(srilanka_tz).strftime("%Y-%m-%d")


print("setting up the stage configuration file into this file")


print("pick the latest trained config file")
def latest_config(config_type):
    '''
    this will pick the latest trained config file
    '''

    s3_path = f"s3://dlk-cloud-tier-8-code-ml-{env}/"
    config_bucket = f"dlk-cloud-tier-8-code-ml-{env}"
    s3 = boto3.client('s3')
    all_objects = s3.list_objects(Bucket = f"dlk-cloud-tier-8-code-ml-{env}", Prefix=f"config_files/{config_type}/{project_name}/")
    model_folder=all_objects['Contents'][-1]['Key']
    #model_path=s3_path+model_folder
    
    return config_bucket, model_folder

print("calling the latest stage config file")
config_type = "stage_config"
config_bucket = latest_config(config_type)[0]
model_path = latest_config(config_type)[1]

print("loading the stage config data from s3")

print("calling the latest stage config file")
config_type = "model_config"
model_hyp_path = latest_config(config_type)[1]

print("loading the stage config data from s3")

print("import the getJsonData function")
def getJsonData(bucket_name,key_name):
    '''
    this will pick the json config file from s3 bucket
    '''
    
    print("[LOG]", bucket_name,'---------')
    print("[LOG]", key_name,'--------------')
      
    s3_client = boto3.client('s3')
    csv_obj = s3_client.get_object(Bucket=bucket_name, Key=key_name)
    
    body = csv_obj['Body']
    
    json_string = body.read().decode('utf-8')
    json_content = json.loads(json_string)
    
    return json_content


config = getJsonData(config_bucket, model_path)
config_hyp = getJsonData(config_bucket, model_hyp_path)



print("json script loaded successfully")
#########################################################################################


if __name__ == "__main__":
    training_data_directory = '/opt/ml/input/data/training/'
    train_features_data = os.path.join(training_data_directory, config["tr_preprocessing"]["local_paths"]["output1"])
    #training_data_directory2 = '/opt/ml/input/data/training2/'
    #train_features_data = os.path.join(training_data_directory2, config["tr_preprocessing"]["local_paths"]["output2"])
    #training_data_directory3 = '/opt/ml/input/data/training3/'
    #train_features_data = os.path.join(training_data_directory3, config["tr_preprocessing"]["local_paths"]["output3"])
    #training_data_directory4 = '/opt/ml/input/data/training4/'
    #train_features_data = os.path.join(training_data_directory4,config["tr_preprocessing"]["local_paths"]["output4"])

    print("Reading input data")
    print("Reading input data from {}".format(train_features_data))
    df_train_features = pd.read_csv(train_features_data, header = None)
    #df_train_features2 = pd.read_csv(train_features_data2, header = None)
    #df_train_features3 = pd.read_csv(train_features_data3, header = None)
    #df_train_features4 = pd.read_csv(train_features_data4, header = None)
    
    columns_ori = config['train_model_dt']['columns']['input1-selected_columns']
    #columns_ori2 = config['train_model_dt']['columns']['input2-selected_columns']
    #columns_ori3 = config['train_model_dt']['columns']['input3-selected_columns']
    #columns_ori4 = config['train_model_dt']['columns']['input4-selected_columns']
    

    print("renaming the columns")
    df_train_features.columns = columns_ori
    #df_train_features2.columns = columns_ori2
    #df_train_features3.columns = columns_ori3
    #df_train_features4.columns = columns_ori4
    
    ####################################### Enter you own script here -- This is a sample code and you shuold repalce this space by your own script
    
    data_df = df_train_features.copy()

    print("split dataset in features and target variable")
    feature_cols = ['AON', 'USAGE_ARPU']
    x = data_df[feature_cols]
    y = data_df.CLUSTER_ID

    print("split dataset into training set and test set")
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42) 

    print("train the model")
    classes_weights = class_weight.compute_sample_weight(
    class_weight='balanced',
    y=y_train
    )

    print("apply grid search")
    dt = DecisionTreeClassifier()
    parameters = {
        'max_depth': config_hyp['dt_param_grid']['max_depth'],
        'criterion': config_hyp['dt_param_grid']['criterion']
    }

    cv = GridSearchCV(dt, parameters, cv=config_hyp['cv'])
    cv.fit(x_train, y_train.values.ravel(), sample_weight=classes_weights)

    ("get the best model")
    final_model = cv.best_estimator_

    ("doing the prediction")
    y_pred = final_model.predict(x_test)

    print("classification_report", classification_report(y_test, y_pred))
    
    ##################### End of your own script #############################
    OUTPUT_DIR = "/opt/ml/model/"
               
    print("Saving the final model....")
    path = os.path.join(OUTPUT_DIR, "temp_dict.pkl")
    print(f"saving to {path}")
    with open(path, 'wb') as p_file:
        pickle.dump(final_model, p_file) #Chanage the final model name
        
   
    print('full training Job is completed.')
