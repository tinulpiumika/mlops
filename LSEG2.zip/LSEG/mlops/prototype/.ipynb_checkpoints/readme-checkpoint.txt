Please read the below instructions, before starting your project on AWS.

Special Notices:
    - you should store first training input dataset in,
    s3://dlk-cloud-tier-10-preprocessed-ml-dev/project_name/tr/sample_input1_dataset/input1/"
    - you should store first inference input dataset in,
    s3://dlk-cloud-tier-10-preprocessed-ml-dev/project_name/inf/sample_input1_dataset/input1/"   
        

1) Change the each folder name according to your BUName and the usecase name.

2) Please follow the below path to open config file management system.
    BUName_usecase_config_file > converting_scripts
    
3) Open converting_stage_config_to_json.ipynb and please do the mentioned changes in the script.(Changes are highlighted as a Python comments)

Special Note:
- In here we developed two seperate pipeline for training and inferencing jobs.
- Training Job has two stages:
    (i) preprocessing stage
    (ii) training stage
    (iii) register model stage
- Inferencing Job has two stages:
    (i) preprocessing stage
    (ii) inferencing stage
    (iii) postprocessing stage
- These steps may be change, according to your requirement. If it's so, please modfiy all the files in the converting_scripts folder.

4) Run all the commands in the file by using the execution button in the top navigator.

5) Open the converting_tr_pipeline_config_to_json.ipynb and please do the mentioned changes in the script.(Changes are highlighted as a Python comments)
    (i) If you do not need to change the instance type, instance count of each stage, you only have to modify the first cell remeber to insert your input datasets' names (If you have only one input dataset, no need to delete or edit, you can skip it).
    (ii)If you need to change the insatnce type and instance count, please follow the comments in the second cell of the script.
    
---------------------------------- Training Pipeline ------------------------------------

6) Go back to the main directory again and follow the below path.
Now we are going to edit the preprocessing script of the project
    BUName_usecase_tr_preprocessing > preprocessing.py

7) You have to do these modfifications to the preprocessing.py files
    (i) Import your neccessary libraries in line 14-19 (you can enter all the necessary libraries into this)
    (ii) Enter your project name with BU Name in line 26 and 27
    (iii) (optional) if you have two input datsets, please uncomment(remove #) line 91, 97, 108 & 109
    (iv) Enter your own script in the given space(Can exceed the given space).
    (v) Enter your final dataframe name in line 121
    (vi) (optional) if you have two output datsets, please uncomment(remove #) line 123-125
    (vii) save the file by pressing "crtl"+"s" command

8) Go back to the main directory again and after that follow the below path.
    Now we are going to edit the training script of the project
    BUName_usecase_tr_training> regressor_model > train.py

9) You have to do these modfifications to the train.py files
    (i) Import your neccessary libraries in line 14-19 (you can enter all the necessary libraries into this)
    (ii) Enter your project name with BU Name in line 26 and 27
    (iii) (optional) if you have two input datsets, please uncomment(remove #) line 101, 111, 116 & 123
    (iv) Enter your own script in the given space. We already entered a sample code and you shuold repalce this space by your own script (Can exceed the given space).
    (v) Enter your final model name in line 170
    (vi) save the file by pressing "crtl"+"s" command
    
10) Go back to BUName_usecase_training folder and please open the Dockerflie. Check the Docker file and if you need to install more libraries into file please edit line 27 to 39 and save the file.

11) Go back to the main directory again and open the build_docker_training.ipynb. Then enter you BUName and the usecase name in the image line and cd line.

12) Go back to the main directory again and open the pipeline_train.ipynb file
    Now we are going to implement a SageMaker pipeline.
    Please do the below modifications to the script.
        (i) please define your project details in the first cell and execute it by pressing the run button.
        (ii) Execute the second cell.
        (iii) If you follow step 7(iii)/9(iii), press "crtl"+"F" and type "input2" and then uncomment the highlighted line.
        (iv) If you follow step 7(vi), press "crtl"+"F" and type "output2" and then uncomment the highlighted line.
        (v) Save the full code and execute the modified cell and the next two cells respectively.
    You can check the status of your pipeline the SageMaker Studio UI (Pipelines -> Pipeline_name)

Now you have sucessfully trained your training SageMaker Pipeline in AWS and now we are going to implement the inference pipeline for your project.

----------------------------------- Inference Pipeline ----------------------------------------

13) Go back to the main directory again and follow the below step to open the convering_inf_pipeline_config_to_json.ipynb notebook. 
BUName_usecase_config_file > converting_scripts > convering_inf_pipeline_config_to_json.ipynb

14) Repeat the step 5.

15) Go back to the main directory again and follow the below path.
    Now we are going to edit the inference preprocessing script of the project
    BUName_usecase_inf_preprocessing > preprocessing.py
    
16) Repeat the process of Step 7

17) Go back to the main directory again and follow the below path.
    Now we are going to edit the inference script of the project
    BUName_usecase_inf_inference/model/predictor.py
        (i) open the file.
        (ii) Enter the column names of the inference preprocessing output table in line 85.
        (iii) Enter your own script in the given spance (line 87-97)
        (iv) save the file by pressing "crtl"+"s" command

18) Go back to BUName_usecase_inf_inference folder and please open the Dockerflie. Check the Docker file and if you need to install more libraries into file please edit line 29 to 34 and save the file.

19) Go back to the main directory again and follow the below path.
    Now we are going to edit the inference postprocessing script of the project
    BUName_usecase_inf_postprocessing > postprocessing.py

20) Repeat the step 7

21) Go back to the main directory again and open the build_docker_inference.ipynb. Then enter you BUName and the usecase name in the image line and cd line.

22) Go back to the main directory again and open the pipeline_inference.ipynb file
    Now we are going to implement a Inference SageMaker pipeline.
    Please repeat the step 12. 
    
    Apart from this if you need to add more inputs/outputs to the post processing please search "post-input2"/ "post-output2" to in the search window. After that uncomment the highlighted fields.

23) Push all the codes into CodeCommit. Need any references : follow the AWS Sagemaker Guideline document

