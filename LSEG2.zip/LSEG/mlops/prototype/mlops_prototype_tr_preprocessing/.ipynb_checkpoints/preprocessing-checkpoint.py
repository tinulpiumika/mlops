import boto3
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)
import argparse
import os
warnings.simplefilter(action='ignore')
import json
import pytz
from datetime import datetime
import boto3

######## import your necessary libraries here
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle




def change_format(df):
    df['TotalCharges'] = pd.to_numeric(df.TotalCharges, errors='coerce')
    
    return df

def missing_value(df):
    print("count of missing values: (before treatment)", df.isnull().sum())
    
    df['TotalCharges'] = df['TotalCharges'].fillna(df['TotalCharges'].mean())
    print("count of missing values: (before treatment)", df.isnull().sum())
    print("missing values successfully replaced")
    return df

def data_manipulation(df):
    df = df.drop(['customerID'], axis = 1)
    
    return df

def cat_encoder(df, variable_list):
    dummy = pd.get_dummies(df[variable_list], drop_first = True)
    df = pd.concat([df, dummy], axis=1)
    df.drop(df[cat_var], axis = 1, inplace = True)
    
    print("Encoded successfully")
    return df

def scaling(X):  
    min_max=MinMaxScaler()
    X=pd.DataFrame(min_max.fit_transform(X),columns=X.columns)
    
    return X


print("setup the date folder to do the data versioning")
srilanka_tz = pytz.timezone('Asia/Colombo')
s3 = boto3.client('s3')
date_folder = datetime.now(srilanka_tz).strftime("%Y-%m-%d")

#########################################################################################
    

if __name__ == "__main__":

    input_data_path = "s3://sagemaker-studio-408970228172-8k2laox6686/data-ingestion/diabetes.csv"
    #input_data_path2 = os.path.join("/opt/ml/processing/input2", config["tr_preprocessing"]["local_paths"]["input2"])
    #input_data_path3 = os.path.join("/opt/ml/processing/input3", config["tr_preprocessing"]["local_paths"]["input3"])
    #input_data_path4 = os.path.join("/opt/ml/processing/input4", config["tr_preprocessing"]["local_paths"]["input4"])

    print("Reading input data")
    df = pd.read_csv(input_data_path)
    #df2 = pd.read_csv(input_data_path2)
    #df3 = pd.read_csv(input_data_path3)
    #df4 = pd.read_csv(input_data_path4)

    df2 = df.fillna(0)
    
    x=df.iloc[:,:8].values
    y=df.iloc[:,8].values

    
    preprocessed_path = 's3://sagemaker-studio-408970228172-8k2laox6686/preprocess/train/x.csv'
    print("Saving output to {}".format(preprocessed_path))
    pd.DataFrame(x).to_csv(preprocessed_path, header=False, index=False) # change the final output dataframe name
    
    preprocessed_path2 = 's3://sagemaker-studio-408970228172-8k2laox6686/preprocess/test/y.csv'
    print("Saving output to {}".format(preprocessed_path2))
    pd.DataFrame(y).to_csv(preprocessed_path2, header=False, index=False) # change the final output dataframe name
    

    
    print("successfully completed the preprocessing")
