import os
import pickle
import boto3
import gzip
from io import BytesIO
#import joblib
import sagemaker
import sagemaker.session

from sagemaker.transformer import Transformer
from sagemaker.estimator import Estimator
from sagemaker.inputs import TrainingInput,TransformInput,CreateModelInput
from sagemaker.processing import (
    ProcessingInput,
    ProcessingOutput,
    ScriptProcessor,
)
from sagemaker.sklearn.processing import SKLearnProcessor
from sagemaker.workflow.conditions import (
    ConditionGreaterThanOrEqualTo,
)
from sagemaker.workflow.condition_step import (
    ConditionStep,
    JsonGet,
)
from sagemaker.model_metrics import (
    MetricsSource,
    ModelMetrics,
)
from sagemaker.workflow.parameters import (
    ParameterInteger,
    ParameterString,
)
from sagemaker.workflow.pipeline import Pipeline
from sagemaker.workflow.properties import PropertyFile
from sagemaker.workflow.steps import (
    ProcessingStep,
    TrainingStep,
    TransformStep,
    CreateModelStep
)
from sagemaker.workflow.step_collections import RegisterModel
from sagemaker.model import Model
from sagemaker.network import NetworkConfig

from datetime import datetime
from dateutil import tz
import json

import pytz
from datetime import datetime

import json
import boto3


sess = sagemaker.Session()

def convert_timezone():
    to_zone = tz.gettz('Asia/Kolkata')
    
    return datetime.utcnow().astimezone(to_zone)

   
def get_session(region, default_bucket):
    """Gets the sagemaker session based on the region.
    Args:
        region: the aws region to start the session
        default_bucket: the bucket to use for storing the artifacts
    Returns:
        `sagemaker.session.Session instance
    """

    boto_session = boto3.Session(region_name=region)

    sagemaker_client = boto_session.client("sagemaker")
    runtime_client = boto_session.client("sagemaker-runtime")
    return sagemaker.session.Session(
        boto_session=boto_session,
        sagemaker_client=sagemaker_client,
        sagemaker_runtime_client=runtime_client,
        default_bucket=default_bucket,
    )



env = 'dev'
project_name = "mobile_prepaidchurn"
job_name = 'tr'

def latest_config():
        
        '''
        this will pick the latest trained config file
        '''

        s3_path = f"s3://dlk-cloud-tier-8-code-ml-{env}/"
        config_bucket = f"dlk-cloud-tier-8-code-ml-{env}"
        s3 = boto3.client('s3')
        all_objects = s3.list_objects(Bucket = f"dlk-cloud-tier-8-code-ml-{env}", Prefix=f"config_files/pipeline_config/{project_name}/")
        model_folder=all_objects['Contents'][-1]['Key']
        #model_path=s3_path+model_folder

        return config_bucket, model_folder

config_s3_bucket = latest_config()[0]
model_s3_path = latest_config()[1]


def getJsonData(bucket_name,key_name):
        '''
        this will pick the json config file from s3 bucket
        '''

        print("[LOG]", bucket_name,'---------')
        print("[LOG]", key_name,'--------------')

        s3_client = boto3.client('s3')
        csv_obj = s3_client.get_object(Bucket=bucket_name, Key=key_name)

        body = csv_obj['Body']

        json_string = body.read().decode('utf-8')
        json_content = json.loads(json_string)

        return json_content


config = getJsonData(config_s3_bucket,model_s3_path)


def get_pipeline(
    region,
    subnets,
    security_group_ids,
    role=None,
    default_bucket=None,
    model_package_group_name=config['pipeline']['pipeline_config']['model_package_group_name'],  # Choose any name
    pipeline_name=config['pipeline']['pipeline_config']['pipeline_name'],  # You can find your pipeline name in the Studio UI (project -> Pipelines -> name)
    base_job_prefix=config['pipeline']['pipeline_config']['base_job_prefix'],
    env=config['pipeline']['pipeline_config']['env']
): # Choose any name
    
    
    srilanka_tz = pytz.timezone('Asia/Colombo')
    s3 = boto3.client('s3')
    #working input data path
    input_data = config['pipeline']['inputs']['input1']
    
    directory_name = config['pipeline']['pipeline_config']['env']
    date_folder = datetime.now(srilanka_tz).strftime("%Y-%m-%d")
       
    sagemaker_session = get_session(region, default_bucket)
    if role is None:
        role = sagemaker.session.get_execution_role(sagemaker_session)
    account_id = boto3.client("sts").get_caller_identity().get("Account")
    region = boto3.session.Session().region_name

    # Parameters for pipeline execution
    processing_instance_count = ParameterInteger(
        name="ProcessingInstanceCount", default_value=1
    )
    
    postprocessing_instance_type = ParameterString(
        name="PostProcessingInstanceType", default_value="ml.m5.2xlarge"
    )
    
    preprocess_output_data1 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/{project_name}/{job_name}/{date_folder}/preprocess_output_data/preprocessed"
    #preprocess_output_data2 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/mobile_prepaidchurn/inference/{date_folder}/preprocess_output_data/X_test"
    #preprocess_output_data3 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/mobile_prepaidchurn/inference/{date_folder}/preprocess_output_data/y_train"
    #preprocess_output_data4 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/mobile_prepaidchurn/inference/{date_folder}/preprocess_output_data/y_test"
    preprocess_output_data5 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/{project_name}/{job_name}/{date_folder}/preprocess_output_data/kmeans"
    
    model_path_tr = ParameterString(
        name="ModelPath",
        default_value=f"s3://dlk-cloud-tier-9-training-ml-{env}/mobile_prepaidchurn/models/decision_tree/{date_folder}", 
    )
    model_path_xg = ParameterString(
        name="ModelPathxg",
        default_value=f"s3://dlk-cloud-tier-9-training-ml-{env}/mobile_prepaidchurn/models/xgboost/{date_folder}", 
    )    
        
    model_approval_status = ParameterString(
        name="ModelApprovalStatus",
        default_value="Approved",  # ModelApprovalStatus can be set to a default of "Approved" if you don't want manual approval.
    )     
 
    generic_tags=[{'Key': 'EnvironmentName', 'Value': env}, 
                  {'Key': 'ProjectName', 'Value': config['pipeline']['generic_tags']['ProjectName']},
                  {'Key': 'DepartmentName', 'Value': config['pipeline']['generic_tags']['DepartmentName']}, 
                  {'Key': 'UsecaseName', 'Value': config['pipeline']['generic_tags']['UsecaseName']},
                  {'Key': 'ResourceName', 'Value': config['pipeline']['generic_tags']['ResourceName']}, 
                  {'Key': 'OwnerName', 'Value': config['pipeline']['generic_tags']['OwnerName']},
                  {'Key': 'BUName', 'Value': config['pipeline']['generic_tags']['BUName']} ]
    

    # --------------------- PREPROCESSING --------------------------------------------------------------------
    ecr_repository = config['tr_preprocessing']['estimator_config']['ecr_repository']
    tag = ":latest"
    uri_suffix = "amazonaws.com"
    
    preprocessing_repository_uri = "{}.dkr.ecr.{}.{}/{}".format(
        account_id, region, uri_suffix, ecr_repository + tag
    )
        
    script_processor = ScriptProcessor(
         command = ["python3"],
         image_uri = preprocessing_repository_uri,
         role = role,
         instance_count = 1,
         instance_type = "ml.m5.2xlarge",
         #tags = generic_tags + [{'Key': 'JobType', 'Value': 'Preprocessing'}],
         network_config = NetworkConfig(subnets=subnets.split(':'), security_group_ids=security_group_ids.split(':'))
    )
    
    step_preprocess = ProcessingStep(
        name=f"{base_job_prefix}-preprocessing",
        processor=script_processor, 
        code=config['tr_preprocessing']['inputs']['code'],
        inputs=[ProcessingInput(input_name="input-1",source=input_data, destination="/opt/ml/processing/input"),
               #ProcessingInput(input_name="input-2", source=input_data1, destination="/opt/ml/processing/input")
               ],
        outputs=[
            ProcessingOutput(output_name="preprocessed", destination=preprocess_output_data1, source="/opt/ml/processing/preprocessed"),
            #ProcessingOutput(output_name="X_test", destination=preprocess_output_data2, source="/opt/ml/processing/X_test"),
            #ProcessingOutput(output_name="y_train", destination=preprocess_output_data3, source="/opt/ml/processing/y_train"),
            #ProcessingOutput(output_name="y_test", destination=preprocess_output_data4, source="/opt/ml/processing/y_test"),
            ProcessingOutput(output_name="kmeans", destination=preprocess_output_data5, source="/opt/ml/processing/kmeans"),
        ]
        #job_arguments=["--env", env],
    )
    
    ##--------------------------------------- Training-Decision Tree-----------------------------------------------------
    
    ecr_repository = config['train_model_dt']['estimator_config']['ecr_repository']
    tag = ":latest"
    uri_suffix = "amazonaws.com"
    
    recommender_image_uri = "{}.dkr.ecr.{}.{}/{}".format(
        account_id, region, uri_suffix, ecr_repository + tag
    )
    
    estimator = Estimator(image_uri=recommender_image_uri,
                      role=role,
                      sagemaker_session=sess,                                  # Technical object
                      output_path=model_path_tr,
                      base_job_name=f"{base_job_prefix}-trainingdt-job",
                      input_mode='File',                                       # Copy the dataset and then train    
                      train_instance_count=config['train_model_dt']['estimator_config']['instance_count'],
                      train_instance_type=config['train_model_dt']['estimator_config']['instance_type'],
                      debugger_hook_config=False,
                      disable_profiler = True,
                      metric_definitions=[
                          # Only 40 Metrics can be accomodated
                            {'Name': 'Training Accuracy:' , 'Regex': 'Training Accuracy: ([-+]?[0-9]*\.?[0-9]+)'},
                            {'Name': 'MAE' , 'Regex': 'MAE: ([-+]?[0-9]*\.?[0-9]+)'},
                            {'Name': 'MSE' , 'Regex': 'MSE: ([-+]?[0-9]*\.?[0-9]+)'},
                            {'Name': 'RMSE' , 'Regex': 'RMSE: ([-+]?[0-9]*\.?[0-9]+)'},
                            #{'Name': 'F1 score:' , 'Regex': 'F1 score:([-+]?[0-9]*\.?[0-9]+)'}
                      ],
                      subnets = subnets.split(':'),
                      security_group_ids = security_group_ids.split(':')
                         )

    # start training
    step_train = TrainingStep(
        name=f"{base_job_prefix}-trainingdt",
        estimator=estimator,
        inputs = {
            "decision": TrainingInput(
                s3_data=step_preprocess.properties.ProcessingOutputConfig.Outputs["kmeans"].S3Output.S3Uri,
                content_type="text/csv",
            ),
        }
    )
    
    ##--------------------------------------- Training-XG boost-----------------------------------------------------
    
    ecr_repository = config['train_model_xgb']['estimator_config']['ecr_repository']
    tag = ":latest"
    uri_suffix = "amazonaws.com"
    
    recommender_image_uri = "{}.dkr.ecr.{}.{}/{}".format(
        account_id, region, uri_suffix, ecr_repository + tag
    )
    
    estimator_xg = Estimator(image_uri=recommender_image_uri,
                      role=role,
                      sagemaker_session=sess,                                  # Technical object
                      output_path=model_path_xg,
                      base_job_name=f"{base_job_prefix}-trainingxg-job",
                      input_mode='File',                                       # Copy the dataset and then train    
                      train_instance_count=config['train_model_xgb']['estimator_config']['instance_count'],
                      train_instance_type=config['train_model_xgb']['estimator_config']['instance_type'],
                      debugger_hook_config=False,
                      disable_profiler = True,
                      metric_definitions=[
                          # Only 40 Metrics can be accomodated
                            {'Name': 'Accuracy: ' , 'Regex': 'Accuracy: ([-+]?[0-9]*\.?[0-9]+)'},
                            {'Name': 'Precision: ' , 'Regex': 'Precision: ([-+]?[0-9]*\.?[0-9]+)'},
                            {'Name': 'Recall: ' , 'Regex': 'Recall: ([-+]?[0-9]*\.?[0-9]+)'},
                            {'Name': 'F1 score: ' , 'Regex': 'f1: ([-+]?[0-9]*\.?[0-9]+)'},
                            {'Name': 'Latency: ' , 'Regex': 'Latency: ([-+]?[0-9]*\.?[0-9]+)'},
                      ],
                      subnets = subnets.split(':'),
                      security_group_ids = security_group_ids.split(':')
                         )

    # start training
    step_train_xg = TrainingStep(
        name=f"{base_job_prefix}-trainingxg",
        estimator=estimator_xg,
        inputs = {"xgb": TrainingInput(
                s3_data=step_preprocess.properties.ProcessingOutputConfig.Outputs["preprocessed"].S3Output.S3Uri,
                content_type="text/csv",
            ),
        }
    )

    ###### --------------------- Model Registry - DT ----------------------------------------------------------------
    
    #registering the DT model

    step_register_dt = RegisterModel(
        name= f"{base_job_prefix}-registerdtmodel",
        estimator= estimator,
        model_data= step_train.properties.ModelArtifacts.S3ModelArtifacts,
        content_types= ["text/csv"],
        response_types= ["text/csv"],
        inference_instances= ["ml.t2.medium", "ml.m5.xlarge"],
        transform_instances= ["ml.m5.xlarge"],
        model_package_group_name=f"{model_package_group_name}-DT",
        approval_status=model_approval_status,
        #model_metrics=model_metrics,
    )
    
    ###### --------------------- Model Registry - XGB ----------------------------------------------------------------
    
    #registering the xgb model

    step_register_xg = RegisterModel(
        name= f"{base_job_prefix}-registerxgbmodel",
        estimator= estimator,
        model_data= step_train_xg.properties.ModelArtifacts.S3ModelArtifacts,
        content_types= ["text/csv"],
        response_types= ["text/csv"],
        inference_instances= ["ml.t2.medium", "ml.m5.xlarge"],
        transform_instances= ["ml.m5.xlarge"],
        model_package_group_name=f"{model_package_group_name}-XGB",
        approval_status=model_approval_status,
        #model_metrics=model_metrics,
    )

    # Pipeline instance
    pipeline = Pipeline(
        name=pipeline_name,
        parameters=[
            env,
            model_approval_status,
            model_path_tr,
            model_path_xg
        ],
        steps=[step_preprocess,
               step_train,
               step_train_xg,
               step_register_dt,
               step_register_xg
              ],
        sagemaker_session=sagemaker_session,
    )
    return pipeline