import os
import pickle
import boto3
import gzip
from io import BytesIO
#import joblib
import sagemaker
import sagemaker.session

from sagemaker.transformer import Transformer
from sagemaker.estimator import Estimator
from sagemaker.inputs import TrainingInput,TransformInput,CreateModelInput
from sagemaker.processing import (
    ProcessingInput,
    ProcessingOutput,
    ScriptProcessor,
)
from sagemaker.sklearn.processing import SKLearnProcessor
from sagemaker.workflow.conditions import (
    ConditionGreaterThanOrEqualTo,
)
from sagemaker.workflow.condition_step import (
    ConditionStep,
    JsonGet,
)
from sagemaker.model_metrics import (
    MetricsSource,
    ModelMetrics,
)
from sagemaker.workflow.parameters import (
    ParameterInteger,
    ParameterString,
)
from sagemaker.workflow.pipeline import Pipeline
from sagemaker.workflow.properties import PropertyFile
from sagemaker.workflow.steps import (
    ProcessingStep,
    TrainingStep,
    TransformStep,
    CreateModelStep
)
from sagemaker.workflow.step_collections import RegisterModel
from sagemaker.model import Model
from sagemaker.network import NetworkConfig

from datetime import datetime
from dateutil import tz
import json

import pytz


sess = sagemaker.Session()


def convert_timezone():
    to_zone = tz.gettz('Asia/Kolkata')
    
    return datetime.utcnow().astimezone(to_zone)

   
def get_session(region, default_bucket):
    """Gets the sagemaker session based on the region.
    Args:
        region: the aws region to start the session
        default_bucket: the bucket to use for storing the artifacts
    Returns:
        `sagemaker.session.Session instance
    """

    boto_session = boto3.Session(region_name=region)

    sagemaker_client = boto_session.client("sagemaker")
    runtime_client = boto_session.client("sagemaker-runtime")
    return sagemaker.session.Session(
        boto_session=boto_session,
        sagemaker_client=sagemaker_client,
        sagemaker_runtime_client=runtime_client,
        default_bucket=default_bucket,
    )



env = 'dev'
project_name = "mobile_prepaidchurn"
job_name = 'inf'


def latest_config():
        
        '''
        this will pick the latest trained config file
        '''

        s3_path = f"s3://dlk-cloud-tier-8-code-ml-{env}/"
        config_bucket = f"dlk-cloud-tier-8-code-ml-{env}"
        s3 = boto3.client('s3')
        all_objects = s3.list_objects(Bucket = f"dlk-cloud-tier-8-code-ml-{env}", Prefix=f"config_files/pipeline_{job_name}_config/{project_name}/")
        model_folder=all_objects['Contents'][-1]['Key']
        #model_path=s3_path+model_folder

        return config_bucket, model_folder

config_s3_bucket = latest_config()[0]
model_s3_path = latest_config()[1]


def getJsonData(bucket_name,key_name):
        '''
        this will pick the json config file from s3 bucket
        '''

        print("[LOG]", bucket_name,'---------')
        print("[LOG]", key_name,'--------------')

        s3_client = boto3.client('s3')
        csv_obj = s3_client.get_object(Bucket=bucket_name, Key=key_name)

        body = csv_obj['Body']

        json_string = body.read().decode('utf-8')
        json_content = json.loads(json_string)

        return json_content


config = getJsonData(config_s3_bucket,model_s3_path)

def model_with_pipeline():

    env='dev'
    s3_path = f"s3://dlk-cloud-tier-9-training-ml-{env}/"
    s3 = boto3.client('s3')
    all_objects = s3.list_objects(Bucket = f"dlk-cloud-tier-9-training-ml-{env}", Prefix=f"mobile_prepaidchurn/models/decision_tree/")
    model_folder=all_objects['Contents'][-1]['Key']
    model_path=s3_path+model_folder
    return model_path

def xg_model_with_pipeline():

    env='dev'
    s3_path = f"s3://dlk-cloud-tier-9-training-ml-{env}/"
    s3 = boto3.client('s3')
    all_objects = s3.list_objects(Bucket = f"dlk-cloud-tier-9-training-ml-{env}", Prefix=f"mobile_prepaidchurn/models/xgboost/")
    model_folder=all_objects['Contents'][-1]['Key']
    model_path=s3_path+model_folder
    return model_path


def get_pipeline(
    region,
    subnets,
    security_group_ids,
    role=None,
    default_bucket=None,
    model_package_group_name=config['pipeline']['pipeline_config']['model_package_group_name'],  # Choose any name
    pipeline_name=config['pipeline']['pipeline_config']['pipeline_name'],  # You can find your pipeline name in the Studio UI (project -> Pipelines -> name)
    base_job_prefix=config['pipeline']['pipeline_config']['base_job_prefix'],
    env='dev'): # Choose any name
    
    srilanka_tz = pytz.timezone('Asia/Colombo')
    s3 = boto3.client('s3')
    #working input data path
    input_data = config['pipeline']['inputs']['input1']
    input_data_1 = config['pipeline']['inputs']['input2']
    input_data1_1 = config['pipeline']['inputs']['input3']

    directory_name = config['pipeline']['pipeline_config']['base_job_prefix']
    date_folder = datetime.now(srilanka_tz).strftime("%Y-%m-%d")
       
    sagemaker_session = get_session(region, default_bucket)
    if role is None:
        role = sagemaker.session.get_execution_role(sagemaker_session)
    account_id = boto3.client("sts").get_caller_identity().get("Account")
    region = boto3.session.Session().region_name

    # Parameters for pipeline execution
    processing_instance_count = ParameterInteger(
        name="ProcessingInstanceCount", default_value=1
    )
    
    postprocessing_instance_type = ParameterString(
        name="PostProcessingInstanceType", default_value="ml.m5.2xlarge"
    )
    
    preprocess_output_data1 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/{project_name}/{job_name}/{date_folder}/preprocess_before_DT/df_clus"
    preprocess_output_data2 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/{project_name}/{job_name}/{date_folder}/preprocess_before_DT/cluster"
    #preprocess_output_data3 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/mobile_prepaidchurn/inference/{date_folder}/preprocess_output_data/y_train"
    #preprocess_output_data4 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/mobile_prepaidchurn/inference/{date_folder}/preprocess_output_data/y_test"

    preprocess_2_output_data1 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/{project_name}/{job_name}/{date_folder}/preprocess_after_DT/train_df"
    preprocess_2_output_data2 = f"s3://dlk-cloud-tier-10-preprocessed-ml-{env}/{project_name}/{job_name}/{date_folder}/preprocess_after_DT/train_original"
    
    post_output_data = f"s3://dlk-cloud-tier-12-postprocessed-ml-{env}/{project_name}/{job_name}/{date_folder}/postprocess/final_base"
     
    model_approval_status = ParameterString(
        name="ModelApprovalStatus",
        default_value="Approved",  # ModelApprovalStatus can be set to a default of "Approved" if you don't want manual approval.
    )

    generic_tags=[{'Key': 'EnvironmentName', 'Value': env}, {'Key': 'ProjectName', 'Value': 'mlops_migration'},{'Key': 'DepartmentName', 'Value': 'dialog_ml'}, {'Key': 'UsecaseName', 'Value': "mobile-prepaidchurn"}, {'Key': 'ResourceName', 'Value': 'sagemaker_notebook'}, {'Key': 'OwnerName', 'Value': 'saranga_gunasekara'}, {'Key': 'BUName', 'Value': 'mobile'} ]
    
    
    # --------------------- PREPROCESSING 1 - Before DT --------------------------------------------------------------------
    ecr_repository = config['preprocessing1']['estimator_config']['ecr_repository']
    tag = ":latest"
    uri_suffix = "amazonaws.com"
    
    preprocessing_repository_uri = "{}.dkr.ecr.{}.{}/{}".format(
        account_id, region, uri_suffix, ecr_repository + tag
    )
        
    script_processor = ScriptProcessor(
         command = ["python3"],
         image_uri = preprocessing_repository_uri,
         role = role,
         instance_count = config['preprocessing1']['estimator_config']['instance_count'],
         instance_type = config['preprocessing1']['estimator_config']['instance_type'],
         tags = generic_tags + [{'Key': 'JobType', 'Value': 'Preprocessing'}],
         network_config = NetworkConfig(subnets=subnets.split(':'), security_group_ids=security_group_ids.split(':'))
    )
    
    step_preprocess = ProcessingStep(
        name=f"{base_job_prefix}-initialpreprocessing",
        processor=script_processor, 
        code=config['preprocessing1']['inputs']['code'],
        inputs=[ProcessingInput(input_name="input",source=input_data, destination="/opt/ml/processing/input"),
               ],
        outputs=[
            ProcessingOutput(output_name="df_clus", destination=preprocess_output_data1, source="/opt/ml/processing/df_clus"),
            ProcessingOutput(output_name="cluster", destination=preprocess_output_data2, source="/opt/ml/processing/cluster"),
            #ProcessingOutput(output_name="y_train", destination=preprocess_output_data3, source="/opt/ml/processing/y_train"),
            #ProcessingOutput(output_name="y_test", destination=preprocess_output_data4, source="/opt/ml/processing/y_test"),
        ]
        #job_arguments=["--env", env],
    )
    
    ##################################### Inference - Decision Tree ##############################
    ecr_repository_inf_dt = config['preprocessing1']['estimator_config']['ecr_repository']
    tag = ":latest"
    uri_suffix = "amazonaws.com"
    
    preprocessing_repository_uri = "{}.dkr.ecr.{}.{}/{}".format(
        account_id, region, uri_suffix, ecr_repository + tag
    )
    
    BU = config['pipeline']['pipeline_config']['BUName']
    prj_name = config['pipeline']['pipeline_config']['project_name']

    step_create_model_dt = CreateModelStep(
        name=f"{base_job_prefix}-createdecisiontreemodel",
        model=Model(#image, 
            image_uri = f"120582440665.dkr.ecr.ap-southeast-1.amazonaws.com/{BU}-{prj_name}-inf-inferencedt-image:latest",
                    model_data=model_with_pipeline(),
                    role = role,
                    sagemaker_session = sagemaker_session,
                    name = f"{base_job_prefix}",
                    vpc_config = {'Subnets':subnets.split(':'),
                                    'SecurityGroupIds': security_group_ids.split(':')}),
        inputs=CreateModelInput(instance_type=config['create_model-dt']['estimator_config']['instance_type'])
    )
    
    model_name_dt = step_create_model_dt.properties.ModelName
    
    transformer_dt = Transformer(model_name=model_name_dt,
                              instance_count=1,
                              #instance_type=instance_type,
                              #strategy='SingleRecord',
                              strategy='MultiRecord',
                              #max_payload=10, 
                              assemble_with="Line",
                              max_concurrent_transforms = 100,
                              instance_type=config['inference-dt']['estimator_config']['instance_type'],
                              output_path=f"s3://dlk-cloud-tier-11-inference-ml-{env}/{project_name}/batch/{date_folder}/",
                              accept='text/csv',
                              tags = generic_tags + [{'Key': 'JobName', 'Value': 'Inference'}]
                )
    
    step_transform_dt = TransformStep(
        name=f"{base_job_prefix}-inferencedecisiontree",
        transformer=transformer_dt,
        inputs=TransformInput(
            data = step_preprocess.properties.ProcessingOutputConfig.Outputs["cluster"].S3Output.S3Uri,
            #data = "s3://dlk-cloud-tier-10-preprocessed-ml-dev/mobile_prepaidchurn/inference_sample_dataset/cluster.csv",
            split_type="Line",
            content_type="text/csv",
            #compression_type = 'Gzip', 
            #input_filter='$[1:]', 
            join_source='Input')
            #output_filter='$[0,-1]')
    )
    
    ################################## Preprocessing 2 -  After DT ####################################
    
    script_processor2 = ScriptProcessor(
         command = ["python3"],
         image_uri = preprocessing_repository_uri,
         role = role,
         instance_count = config['preprocessing2']['estimator_config']['instance_count'],
         instance_type = config['preprocessing2']['estimator_config']['instance_type'],
         tags = generic_tags + [{'Key': 'JobType', 'Value': 'Preprocessing'}],
         network_config = NetworkConfig(subnets=subnets.split(':'), security_group_ids=security_group_ids.split(':'))
    )
    
    step_preprocess2 = ProcessingStep(
        name=f"{base_job_prefix}-secondpreprocessing",
        processor=script_processor2, 
        code=config['preprocessing2']['inputs']['code'],
        inputs=[ProcessingInput(input_name="input1",
                                source=step_transform_dt.properties.TransformOutput.S3OutputPath,
                                destination="/opt/ml/processing/input1", s3_data_type='S3Prefix'),
               ProcessingInput(input_name="input2", 
                               source=step_preprocess.properties.ProcessingOutputConfig.Outputs["df_clus"].S3Output.S3Uri, 
                               destination="/opt/ml/processing/input2")
               ],
        outputs=[
            ProcessingOutput(output_name="train_df", destination=preprocess_2_output_data1, source="/opt/ml/processing/train_df"),
            ProcessingOutput(output_name="train_original", destination=preprocess_2_output_data2, source="/opt/ml/processing/train_original"),
            #ProcessingOutput(output_name="y_train", destination=preprocess_output_data3, source="/opt/ml/processing/y_train"),
            #ProcessingOutput(output_name="y_test", destination=preprocess_output_data4, source="/opt/ml/processing/y_test"),
        ]
        #job_arguments=["--env", env],
    )
    
    ##########################  Inference - XG Boost   ############################
    
    step_create_model_xg = CreateModelStep(
        name=f"{base_job_prefix}-createxgmodel",
        model=Model(#image, 
            image_uri = f"120582440665.dkr.ecr.ap-southeast-1.amazonaws.com/{BU}-{prj_name}-inf-inferencexg-image:latest",
                    model_data= xg_model_with_pipeline(),
                    role = role,
                    sagemaker_session = sagemaker_session,
                    name = f"{base_job_prefix}",
                    vpc_config = {'Subnets':subnets.split(':'),
                                    'SecurityGroupIds': security_group_ids.split(':')}),
        inputs=CreateModelInput(instance_type=config['create_model-xgb']['estimator_config']['instance_type'])
    )
    
    model_name_xg = step_create_model_xg.properties.ModelName
    
    transformer_xg = Transformer(model_name=model_name_xg,
                              instance_count=config['inference-xgb']['estimator_config']['instance_count'],
                              #instance_type=instance_type,
                              #strategy='SingleRecord',
                              strategy='MultiRecord',
                              #max_payload=10, 
                              assemble_with="Line",
                              max_concurrent_transforms = 100,
                              instance_type=config['inference-xgb']['estimator_config']['instance_type'],
                              output_path=f"s3://dlk-cloud-tier-11-inference-ml-{env}/{project_name}/xgboost/{date_folder}/",
                              accept='text/csv',
                              tags = generic_tags + [{'Key': 'JobName', 'Value': 'Inference'}]
                )
    
    step_transform_xg = TransformStep(
        name=f"{base_job_prefix}-inferencexgboost",
        transformer=transformer_xg,
        inputs=TransformInput(
            data = step_preprocess2.properties.ProcessingOutputConfig.Outputs["train_df"].S3Output.S3Uri,
            ##data = "s3://dlk-cloud-tier-10-preprocessed-ml-dev/mobile_prepaidchurn/inference/2022-03-08/preprocess_output_data/train_df/train_df.csv",
            split_type="Line",
            content_type="text/csv",
            #compression_type = 'Gzip', 
            #input_filter='$[1:]', 
            join_source='Input')
            #output_filter='$[0,-1]')
    )
    
    # --------------------- POST-PROCESSING --------------------------------------------------------------------
    
    script_processor3 = ScriptProcessor(
         command = ["python3"],
         image_uri = preprocessing_repository_uri,
         role = role,
         instance_count = config['preprocessing2']['estimator_config']['instance_count'],
         instance_type = config['preprocessing2']['estimator_config']['instance_type'],
         tags = generic_tags + [{'Key': 'JobType', 'Value': 'Postprocessing'}],
         network_config = NetworkConfig(subnets=subnets.split(':'), security_group_ids=security_group_ids.split(':'))
    )
    
    step_preprocess3 = ProcessingStep(
        name=f"{base_job_prefix}-postprocessing",
        processor=script_processor3, 
        code=config['postpreprocessing']['inputs']['code'],
        inputs=[ProcessingInput(input_name="input-1",
                                source=step_transform_xg.properties.TransformOutput.S3OutputPath, 
                                destination="/opt/ml/processing/input1",
                               s3_data_type='S3Prefix'),
               ProcessingInput(input_name="input-2", 
                               source= step_preprocess2.properties.ProcessingOutputConfig.Outputs["train_original"].S3Output.S3Uri, 
                               destination= "/opt/ml/processing/input2")
               ],
        outputs=[
            ProcessingOutput(output_name="final-output", destination=post_output_data, source="/opt/ml/processing/final_base"),
        #ProcessingOutput(
            #output_name="validation", source="/opt/ml/processing/val", destination=val_data_path
        #),
        ]
        #job_arguments=["--env", env],
    )
        
    # Pipeline instance
    pipeline = Pipeline(
        name=pipeline_name,
        parameters=[
            env,
            model_approval_status,
        ],
        steps=[step_preprocess,
               step_create_model_dt,
               step_transform_dt, 
               step_preprocess2,
               step_create_model_xg,
               step_transform_xg,
               step_preprocess3
              ],
        sagemaker_session=sagemaker_session,
    )
    return pipeline